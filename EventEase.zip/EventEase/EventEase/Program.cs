using EventEase.Models;
using Microsoft.EntityFrameworkCore;
using Azure.Storage.Blobs;

namespace EventEase
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Load configuration
            var configuration = builder.Configuration;

            // Register BlobServiceClient using StorageAccount connection string from appsettings.json
            var blobConnectionString = configuration.GetConnectionString("StorageAccount");
            builder.Services.AddSingleton(new BlobServiceClient(blobConnectionString));

            // Add DbContext
            builder.Services.AddDbContext<EaseDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            


            builder.Services.AddDbContext<EaseDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            builder.Services.AddControllersWithViews(); 



            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}

