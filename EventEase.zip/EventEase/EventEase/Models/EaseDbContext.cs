﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Models;

public partial class EaseDbContext : DbContext
{
    public EaseDbContext()
    {
    }

    public EaseDbContext(DbContextOptions<EaseDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Event> Events { get; set; }

    public virtual DbSet<Venue> Venues { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=tcp:anyservername.database.windows.net,1433;Initial Catalog=easedb;Persist Security Info=False;User ID=ST10264154;Password=Spinhircic54;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PK__Bookings__73951ACDB989F96F");

            entity.Property(e => e.BookingId).HasColumnName("BookingID");
            entity.Property(e => e.BookingDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.BookingPayment).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.EventIdFk).HasColumnName("EventID_FK");
            entity.Property(e => e.VenueIdFk).HasColumnName("VenueID_FK");

            entity.HasOne(d => d.EventIdFkNavigation)
                .WithMany(p => p.Bookings) // Event can have many bookings
                .HasForeignKey(d => d.EventIdFk)
                .HasConstraintName("FK__Bookings__EventI__3D5E1FD2");

            entity.HasOne(d => d.VenueIdFkNavigation)
                .WithMany(p => p.Bookings)
                .HasForeignKey(d => d.VenueIdFk)
                .HasConstraintName("FK__Bookings__VenueI__3E52440B");
        });
    



    modelBuilder.Entity<Event>(entity =>
        {
            entity.HasKey(e => e.EventId).HasName("PK__Events__7944C87068FE4416");

            entity.Property(e => e.EventId).HasColumnName("EventID");
            entity.Property(e => e.EventDate).HasColumnType("datetime");
            entity.Property(e => e.EventDescription).IsUnicode(false);
            entity.Property(e => e.EventName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.VenueIdFk).HasColumnName("VenueID_FK");

            entity.HasOne(d => d.VenueIdFkNavigation).WithMany(p => p.Events)
                .HasForeignKey(d => d.VenueIdFk)
                .HasConstraintName("FK__Events__VenueID___3A81B327");
        });

        modelBuilder.Entity<Venue>(entity =>
        {
            entity.HasKey(e => e.VenueId).HasName("PK__Venues__3C57E5D206526EB7");

            entity.HasIndex(e => e.VenueName, "UQ__Venues__A40F8D120E323185").IsUnique();

            entity.Property(e => e.VenueId).HasColumnName("VenueID");
            entity.Property(e => e.ImageUrl)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("ImageURL");
            entity.Property(e => e.VenueLocation)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.VenueName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.VenuePrice).HasColumnType("decimal(10, 2)");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
