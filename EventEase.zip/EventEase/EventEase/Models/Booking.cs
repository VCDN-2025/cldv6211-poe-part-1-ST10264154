﻿using System;
using System.Collections.Generic;

namespace EventEase.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public int? EventIdFk { get; set; }

    public int? VenueIdFk { get; set; }

    public DateTime? BookingDate { get; set; }

    public decimal BookingPayment { get; set; }

    
    public Event EventIdFkNavigation { get; set; }


    public Venue VenueIdFkNavigation { get; set; }
}
