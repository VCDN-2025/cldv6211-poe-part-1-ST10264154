﻿using System.ComponentModel.DataAnnotations;

namespace EventEase.Models
{
    public class Event
    {
        public int EventId { get; set; }

        [Required(ErrorMessage = "Venue is required.")]
        public int VenueIdFk { get; set; }

        [Required(ErrorMessage = "Event name is required.")]
        [StringLength(100)]
        public string EventName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event description is required.")]
        public string EventDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Event date is required.")]
        public DateTime EventDate { get; set; }

        [Required(ErrorMessage = "Start date is required.")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End date is required.")]
        public DateTime EndDate { get; set; }

        public string? ImageUrl { get; set; }

        public virtual Venue VenueIdFkNavigation { get; set; } = new Venue();

        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}


