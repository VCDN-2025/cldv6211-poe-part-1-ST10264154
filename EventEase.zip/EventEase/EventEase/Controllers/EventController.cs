﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EventEase.Models;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace EventEase.Controllers
{
    public class EventController : Controller
    {
        private readonly EaseDbContext _context;
        private readonly BlobServiceClient _blobServiceClient;
        private readonly BlobContainerClient _containerClient;
        private const string ContainerName = "myfiles";

        public EventController(EaseDbContext context, BlobServiceClient blobServiceClient)
        {
            _context = context;
            _blobServiceClient = blobServiceClient;
            _containerClient = _blobServiceClient.GetBlobContainerClient(ContainerName);
            _containerClient.CreateIfNotExists();
        }

        // GET: Event
        public async Task<IActionResult> Index()
        {
            var events = await _context.Events.Include(e => e.VenueIdFkNavigation).ToListAsync();
            return View(events);
        }

        // GET: Event/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var @event = await _context.Events
                .Include(e => e.VenueIdFkNavigation)
                .FirstOrDefaultAsync(m => m.EventId == id);

            if (@event == null)
                return NotFound();

            return View(@event);
        }

        // GET: Event/Create
        public IActionResult Create()
        {
            ViewData["VenueIdFk"] = new SelectList(_context.Venues, "VenueId", "VenueName");
            return View();
        }

        // POST: Event/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Event @event, IFormFile ImageFile)
        {
            if (ModelState.IsValid)
            {
                // Upload image to Blob Storage if provided
                if (ImageFile != null && ImageFile.Length > 0)
                {
                    var imageUrl = await UploadFileToBlobAsync(ImageFile);
                    @event.ImageUrl = imageUrl;
                }

                _context.Add(@event);
                await _context.SaveChangesAsync();

                return RedirectToAction("Details", new { id = @event.EventId });
            }

            ViewData["VenueIdFk"] = new SelectList(_context.Venues, "VenueId", "VenueName", @event.VenueIdFk);
            return View(@event);
        }
  



// GET: Event/Edit/5
public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var @event = await _context.Events.FindAsync(id);
            if (@event == null)
                return NotFound();

            ViewData["VenueIdFk"] = new SelectList(_context.Venues, "VenueId", "VenueName", @event.VenueIdFk);
            return View(@event);
        }

        // POST: Event/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventId,VenueIdFk,EventName,EventDate,EventDescription,StartDate,EndDate,ImageUrl")] Event @event, IFormFile ImageFile)
        {
            if (id != @event.EventId)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    if (ImageFile != null && ImageFile.Length > 0)
                    {
                        var imageUrl = await UploadFileToBlobAsync(ImageFile);
                        @event.ImageUrl = imageUrl;
                    }

                    _context.Update(@event);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EventExists(@event.EventId))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["VenueIdFk"] = new SelectList(_context.Venues, "VenueId", "VenueName", @event.VenueIdFk);
            return View(@event);
        }

        // GET: Event/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var @event = await _context.Events
                .Include(e => e.VenueIdFkNavigation)
                .FirstOrDefaultAsync(m => m.EventId == id);

            if (@event == null)
                return NotFound();

            return View(@event);
        }

        // POST: Event/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var @event = await _context.Events.FindAsync(id);
            if (@event != null)
            {
                _context.Events.Remove(@event);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool EventExists(int id)
        {
            return _context.Events.Any(e => e.EventId == id);
        }

        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var blobClient = _containerClient.GetBlobClient(fileName);
            await blobClient.UploadAsync(file.OpenReadStream(), overwrite: true);
            return blobClient.Uri.ToString();
        }
    }
}

